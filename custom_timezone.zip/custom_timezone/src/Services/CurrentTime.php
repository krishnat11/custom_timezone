<?php

namespace Drupal\custom_timezone\Services;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Config\ConfigFactory;

/**
 * Class CurrentTime.
 */
class CurrentTime {
    
    protected $config;
    public function __construct(ConfigFactory $config) {
        $this->config = $config;
    }
    
    public static function create(ContainerInterface $container) {
     $config = $container->get('config.factory'); 
     return new Static();
    }
    
    function currentTime(){
        $config = $this->config->get('custom_timezone.settings');
        $currentTimeZone = $config->get('timezone');
        $date = \Drupal::time()->getCurrentTime();
        $date_output =  \Drupal::service('date.formatter')->format($date, 'custom', 'j F Y - h:ia', $currentTimeZone, '');
        return $date_output;
    }
}
