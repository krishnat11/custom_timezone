
CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Configuration

INTRODUCTION
------------

The Custom timezone module provides block with current time based on selected timezone from config. 

CONFIGURATION
-------------

To configure AddToAny, go to:
Administration > Configuration > System > TimeZone Settings Form.

URL : /admin/config/timezone-setting